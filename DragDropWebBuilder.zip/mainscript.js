$(document).ready(function() {
	Vvveb.Builder.init('demo/index.html', function() {
		//load code after page is loaded here
		Vvveb.Gui.init();
	});
	$('#cloud-print').click(function(){
		let frameCont = document.getElementsByTagName('iframe')[0];
		let gadget = new cloudprint.Gadget(),
		htmlToWrite = frameCont.contentWindow.document.documentElement.outerHTML;
		gadget.setPrintDocument('text/html', 'template_' + Date.now(), htmlToWrite, 'utf-8');
		gadget.openPrintDialog();
	});
});
